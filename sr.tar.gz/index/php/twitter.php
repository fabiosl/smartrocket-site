<?php
	include_once (dirname(dirname(__FILE__)).'/CONFIG.php');
	echo 'var twitterName = "'.$twitter_name.'";';
?>